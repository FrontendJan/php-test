-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Počítač: 127.0.0.1
-- Vytvořeno: Stř 02. srp 2023, 15:26
-- Verze serveru: 10.4.28-MariaDB
-- Verze PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `test`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `zaznamy`
--

CREATE TABLE `zaznamy` (
  `id` int(10) NOT NULL,
  `jmeno` varchar(64) NOT NULL,
  `prijmeni` varchar(64) NOT NULL,
  `datum` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Vypisuji data pro tabulku `zaznamy`
--

INSERT INTO `zaznamy` (`id`, `jmeno`, `prijmeni`, `datum`) VALUES
(1, 'Katarína', 'Peka?ová', '2009-04-27'),
(2, 'Vlastimila', 'Chvojka', '2009-02-05'),
(3, 'Viktor', 'Matuška', '2008-09-15'),
(4, 'Ta?ána', 'Jakubcová', '2008-07-12'),
(5, 'Miroslav', 'Rezková', '2008-02-23'),
(6, 'Iveta', 'Vacková', '2008-07-16'),
(7, 'Ivanka', 'David', '2008-06-17'),
(8, 'Na?a', 'Hor?áková', '2008-07-24'),
(9, 'Jaruška', 'Kohoutková', '2009-04-29'),
(10, 'Drahuše', 'K?enková', '2008-08-16'),
(11, 'Dominika', 'Langerová', '2009-07-01'),
(12, 'Robert', 'Mina?íková', '2008-12-04'),
(13, 'Zlata', 'P?íhodová', '2008-11-16'),
(14, 'Jan', 'Trojanová', '2009-01-05'),
(15, 'Radka', 'Beránková', '2009-10-16'),
(16, 'Ota', 'Hloušek', '2008-08-15'),
(17, 'Natalia', 'Hromádková', '2008-12-27'),
(18, 'Matouš', 'Ježek', '2008-08-14'),
(19, 'Otakar', 'Do?ekalová', '2008-04-19'),
(20, 'Mat?j', 'Chvátalová', '2008-07-23'),
(21, 'Bed?iška', 'Tomek', '2009-08-01'),
(22, 'Sylvie', 'Suk', '2009-09-28'),
(23, 'Lydie', 'Maršíková', '2009-03-27'),
(24, 'Marcel', 'Pavlíková', '2008-12-04'),
(25, 'Anton', 'Šolcová', '2008-08-29'),
(26, 'Kv?tuše', 'Vernerová', '2008-07-19'),
(27, 'Ferdinand', 'Nový', '2008-12-01'),
(28, 'Alice', 'Urban', '2009-05-16'),
(29, 'Dobromila', 'Michalcová', '2009-03-14'),
(30, 'Ema', 'Mrázová', '2008-03-08'),
(31, 'Jonáš', 'Dvo?á?ková', '2008-06-03'),
(32, 'Jolana', 'Široký', '2009-05-04'),
(33, 'Mária', 'Záme?ník', '2008-07-20'),
(34, 'Oleg', 'Hlavatý', '2008-09-27'),
(35, 'Marie', 'Chvátalová', '2009-03-14'),
(36, 'Andriy', 'Šandová', '2009-01-27'),
(37, 'Zoltán', 'Sokolová', '2008-07-27'),
(38, 'Volodymyr', '?ervinka', '2009-06-13'),
(39, 'Žaneta', '?ervenka', '2008-08-09'),
(40, 'Agáta', 'Kubeš', '2008-12-30'),
(41, 'Viera', 'Št?pánová', '2009-08-05'),
(42, 'Tetyana', 'Š?astná', '2008-08-27'),
(43, 'Brigita', 'Koš?álová', '2008-04-02'),
(44, 'Ondrej', 'Kubí?ek', '2009-11-06'),
(45, 'Valérie', 'Zemánková', '2008-07-08'),
(46, 'Bohuslava', 'Komínková', '2008-12-21'),
(47, 'Ema', 'Sou?ek', '2008-02-27'),
(48, 'Kate?ina', 'Dvo?áková', '2009-02-23'),
(49, 'Radka', 'Chmelík', '2009-02-03'),
(50, 'Milada', 'Sojka', '2009-04-19'),
(51, 'Old?ich', 'Prokeš', '2008-03-15'),
(52, 'Božena', 'Smékalová', '2009-08-16'),
(53, 'Renata', 'Vaní?ková', '2008-05-12'),
(54, 'Lud?k', 'Tr?ka', '2009-07-19'),
(55, 'Renáta', 'Pavlasová', '2009-03-04'),
(56, 'Sofie', 'Zítková', '2008-06-29'),
(57, 'Lud?k', 'Hradecký', '2009-04-10'),
(58, 'Kv?toslava', 'Sedlák', '2009-01-04'),
(59, 'Stepan', 'Š?astná', '2009-04-28'),
(60, 'Renáta', 'Radová', '2009-03-16'),
(61, 'Miloslava', 'Vaculík', '2008-11-03'),
(62, 'Vitaliy', 'Sojka', '2008-07-30'),
(63, 'Petra', 'Do?ekalová', '2008-08-21'),
(64, 'Romana', 'Nedv?d', '2009-09-20'),
(65, 'Aneta', 'Soukupová', '2009-04-29'),
(66, 'Na?a', 'Pr?cha', '2009-03-25'),
(67, 'Ludmila', 'Ottová', '2008-12-24'),
(68, 'Mojmír', 'Jílková', '2009-11-24'),
(69, 'Zd?nka', '?ejka', '2008-05-04'),
(70, 'Božena', 'Tr?ková', '2008-04-30'),
(71, 'Beata', 'Škoda', '2008-11-08'),
(72, 'Jakub', 'Komínková', '2008-10-12'),
(73, 'Adrian', 'Kade?ábková', '2009-09-07'),
(74, 'Jozef', 'Slaví?ková', '2008-04-30'),
(75, 'Št?pánka', 'Synek', '2008-08-22'),
(76, 'Romana', 'Cibulková', '2009-01-31'),
(77, 'Antonín', 'Havlík', '2009-06-08'),
(78, 'Alžb?ta', 'Sokol', '2008-08-16'),
(79, 'Petr', 'Dobrovolný', '2008-07-15'),
(80, 'Laura', 'Machálková', '2008-05-23'),
(81, 'Lyudmyla', 'Suchánek', '2008-03-14'),
(82, 'Františka', 'Šim?nek', '2008-11-12'),
(83, 'Ivanka', 'Michalová', '2008-08-23'),
(84, 'Zita', '?ervinka', '2009-02-22'),
(85, 'Št?pánka', 'P?ibylová', '2009-10-07'),
(86, 'Dita', 'Janoušková', '2009-10-07'),
(87, 'Emanuel', 'Bobková', '2009-05-06'),
(88, 'Karolina', 'Francová', '2008-06-11'),
(89, 'Radomír', 'Zouhar', '2008-09-03'),
(90, 'Radka', 'Kocourková', '2008-03-25'),
(91, 'Svatava', 'Jav?rek', '2009-11-30'),
(92, 'Robert', 'Máchová', '2009-10-26'),
(93, 'Halina', 'Šafránek', '2009-01-14'),
(94, 'Emilie', 'Dolejš', '2009-03-27'),
(95, 'Matyáš', 'Záme?ník', '2008-09-06'),
(96, 'Michael', 'Vacek', '2008-07-30'),
(97, 'Norbert', 'Procházková', '2008-08-27'),
(98, 'Miroslav', '?ápová', '2009-11-29'),
(99, 'Simona', 'Králíková', '2008-04-14'),
(100, 'Iryna', 'Hladíková', '2009-02-25');

--
-- Indexy pro exportované tabulky
--

--
-- Indexy pro tabulku `zaznamy`
--
ALTER TABLE `zaznamy`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `zaznamy`
--
ALTER TABLE `zaznamy`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
