<?php
//připojení k mysql databázi
$serverName = "localhost";
$userName = "root";
$password = "";
$dbName = "test";

$con = mysqli_connect($serverName, $userName, $password, $dbName,);
?>

<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href = "style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="jquery.js"> </script>
    <title>Document</title>
</head>
<body>
<div class="container d-flex justify-content-center text-center">
    <table class="table table-bordered w-50 shadow">
      <tr>
        <th><h1>Záznamy</h1></th>
      </tr>
      <tr>
      <?php
      //získání dat z json souboru
        $data = file_get_contents("zaznamy.json");
        $data = json_decode($data, true);
      //seřazení přenesení dat
        rsort($data);
        foreach($data as $row){
          $sql = "insert into zaznamy values ('".$row["id"]."', '".$row["jmeno"]."', 
        '".$row["prijmeni"]."','".$row["date"]."')order by id desc" ;
        mysqli_query($con, $sql);
        //zobrazení dat 
          echo '<tr class="zaznam"><td onclick="function()">'.'<img class="rounded w-25" src="assets/profile.jpg"> <br>'.$row["id"].'<br>'.$row["jmeno"].' '.$row["prijmeni"].'<br>'.$row["date"].'</td></tr>';
        }
      ?>
      </tr>
    </table>
</div>

<script>$(document).ready(function() {
    $("td").click(function() {
      // Toggle the background color of the clicked <td> tag
      $(this).toggleClass("clicked");
    });
  });</script>

</body>
</html>